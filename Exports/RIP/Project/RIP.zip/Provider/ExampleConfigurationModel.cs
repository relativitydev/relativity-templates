﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class ExampleConfigurationModel
    {
        public string ConfigSetting1 { get; set; }
        public string ConfigSetting2 { get; set; }
        public string ConfigSetting3 { get; set; }
    }
}
