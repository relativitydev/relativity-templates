﻿using Relativity.Kepler.Services;

namespace $ext_safeprojectname$.$safeprojectname$.$ext_ServiceModule$
{
	/// <summary>
	/// $ext_ServiceModule$ Module Interface.
	/// </summary>
	[ServiceModule("$ext_ServiceModule$ Module")]
	[RoutePrefix("$ext_ServiceModule$", VersioningStrategy.Namespace)]
	public interface $safeitemrootname$
	{
	}
}