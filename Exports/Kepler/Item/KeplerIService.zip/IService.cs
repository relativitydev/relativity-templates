﻿using System;
using System.Threading.Tasks;
using Relativity.Kepler.Services;

namespace $rootnamespace$
{
	[WebService("$safeitemrootname$ Service")]
	[ServiceAudience(Audience.Public)]
	[RoutePrefix("$safeitemrootname$")]
	public interface $safeitemrootname$ : IDisposable
	{
		[HttpPost]
		[Route("")]
		Task $safeitemrootname$Async();
	}
}