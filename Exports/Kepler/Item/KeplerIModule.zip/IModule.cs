﻿using Relativity.Kepler.Services;

namespace $rootnamespace$
{
	[ServiceModule("$safeitemrootname$ Module")]
	[RoutePrefix("$safeitemrootname$", VersioningStrategy.Namespace)]
	public interface $safeitemrootname$
	{
	}
}