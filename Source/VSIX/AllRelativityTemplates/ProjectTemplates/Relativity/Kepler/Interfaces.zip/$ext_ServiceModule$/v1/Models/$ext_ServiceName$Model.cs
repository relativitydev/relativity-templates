﻿namespace $ext_safeprojectname$.$safeprojectname$.$ext_ServiceModule$.v1.Models
{
	/// <summary>
	/// $safeitemrootname$ Data Model.
	/// </summary>
	public class $safeitemrootname$
	{
		/// <summary>
		/// Name property.
		/// </summary>
		public string Name { get; set; }
	}
}
